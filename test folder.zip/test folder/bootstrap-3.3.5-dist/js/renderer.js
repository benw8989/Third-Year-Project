var vCoid = '1'; // this variable is used in the original API to show functionality
var searchterm = ""; // the string that is input for the search box function.
var finalsearchterm = ""; // another string that is used for the search box function.
var randCOId = Math.floor((Math.random() * 3482) + 1); // this is used to get a random number for COId of all objects in the database. This is used in home page to generate a random item from the collection
$(document).ready(function() {
    renderItem();
});
function renderRandomItem() { //this function passes the random number into an API call to get back a singular object in JSON.
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_item/coid/' + randCOId + '/format/json',
        function(jsonObj) {
            renderRandItem(jsonObj); // calls to the rendered, this sends it back to the HTML in a format that HTML can read.
        });
}

function renderItem() { // this function was created by the original owner of the API Ben Jackson
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_item/coid/' + vCoid + '/format/json',
        function(jsonObj) {
            renderRchResults(jsonObj);
        });
}

function renderItemTitle() { // this function was created by the original owner of the API Ben Jackson
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_item/coid/' + vCoid + '/format/json',
        function(jsonObj) {
            renderRchResultsTitle(jsonObj);
        });
}

function renderRelated() { // this function was created by the original owner of the API Ben Jackson
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/fetch_related_objects/coid/' + vCoid + '/format/json',
        function(jsonObj) {
            renderRchRelated(jsonObj);
        });
}
//function renderRelatedItems(nCOId) {
function renderRelatedItems() { // this function was created by the original owner of the API Ben Jackson
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_related_items/coid/' + vCoid + '/offset/0/size/100/format/json',
        function(jsonObj) {
            renderRchRelatedItems(jsonObj);
        });
}

function renderRelatedList() { // this function was created by the original owner of the API Ben Jackson
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_related_list/coid/' + vCoid + '/offset/0/size/100/format/json',
        function(jsonObj) {
            renderRchRelatedList(jsonObj);
        });
}

function renderMediaObject() { // this function was created by the original owner of the API Ben Jackson
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_associated_media_object/amoid/1/format/json',
        function(jsonObj) {
            renderRchMediaObject(jsonObj);
        });
}

function renderAssociated() { // this function was created by the original owner of the API Ben Jackson
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_associated_media/coid/' + vCoid + '/format/json',
        function(jsonObj) {
            renderRchAssociated(jsonObj);
        });
}

function renderMuseumList() { // this function was created by the original owner of the API Ben Jackson
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_museum_list/format/json',
        function(jsonObj) {
            renderRchMuseumList(jsonObj);
        })
}

function renderCollectionByMuseum() { // this function was created by the original owner of the API Ben Jackson
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_collection_by_museum/museum/British%20Museum/offset/4/size/4/format/json',
        function(jsonObj) {
            renderRchCollectionByMuseum(jsonObj);
        });
}
function renderAllVideos() { // created by the original API owner Ben Jackson
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_all_videos/format/json', 
        function(jsonObj) {
            renderRchVideosAll(jsonObj); 
        });
}
function renderAllTheVideos() { // this function renders all unique videos.
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_all_videos/format/json', //gets all videos in a JSON format.
        function(jsonObj) {
            renderVideosAll(jsonObj); // passes the JSON data to uniquely identify videos and then pass them to a HTML format to be read.
        });
}
function renderCollection() { // created by the original API owner Ben Jackson
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_collection_list/format/json',
        function(jsonObj) {
            renderRchCollection(jsonObj);
        });
}
function searchQuery() { //This function is used for the quick search function at the top of the page.
    $.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_collection_list/format/json', //return all objects in the database
        function(jsonObj) {
            searchTerm(jsonObj); //pass all JSON objects from the database to then be processed.
        });
}
function getMuseumSliders(){// this function renders the browse collections slider using a the Jssor plug-in
	$.getJSON('http://sierraleone.heritageinformatics.org/index.php/api/search_service/get_collection_list/format/json', //returns entire collection of objects that are in the database.
        function(jsonObj) {
            renderMuseumSliders(jsonObj); // passes all objects to then be processed by implementing the Jssor plug-in on certain objects.
        });
	
}

function setCoid(){ // this function was created by the original owner of the API Ben Jackson
    
    vCoid = document.getElementById("txtCoid").value;
}
function searchTerm(json_data){
	var coidToSearch = []; //create an array for all objects to be searched through at the end.
	//coidToSearch.push("1029");
	var res = "";
	searchterm = window.location.search;
	var manip = searchterm.replace("?searchTerm=", ""); // replaces search term with nothing
	finalsearchterm = manip.replace(/\+/g, " ");  // replaces all instances of + as a space
	finalfinalsearchterm = finalsearchterm.replace(/\sa\s|\sthe\s|a\s|the\s|\sis\s|\sand\s|and\s|\sof\s|of\s|\sis|\sthe|\sa/gi, " "); // filters out any rubbish words to send through the database
	var results = finalfinalsearchterm.match(/\w+|\d+\s?/gi); // puts all remaining words into an array of words to search.
	
	for (o = 0; o<results.length; o++){
		results[o] = results[o].replace(/\W/gi, ""); //elimates any excess characters.
		
	}
	for(y=0; y<results.length; y++){ //for every word in the array
  	for(t=0; t<json_data.data.length; t++){			  // for every object in the database
			var isit = false; // boolean variable to check if a COId is in the coidToSearch
		for(j=0; j<coidToSearch.length; j++){  
			if(json_data.data[t].COId-1 == coidToSearch[j]){
				isit = true; //if the COId is already in the array it will skip the next step
			}
		}
			if ((json_data.data[t].Description.indexOf(results[y])>-1) && !isit){ // if not already in coidToSearch add the coid of object to the array
				coidToSearch.push(json_data.data[t].COId-1);				
			}
			else if((json_data.data[t].COId == results[y]) && !isit){ // if not already in coidToSearch add the coid of object to the array
				coidToSearch.push(json_data.data[t].COId-1);			
			}					
		}
		
	}
	
	res += "<p><h1>Search results for: " + results.toString() + "</h1></p>";  //returns in the HTMl what the user searched for.
	for(x=0; x<coidToSearch.length;x++){
	
	res += "<p>";
	 res += "<li>COId: " + json_data.data[coidToSearch[x]].COId + '</li>';	
	 res += "<li>Object: " + json_data.data[coidToSearch[x]].Object + '</li>';
	 res += "<li>Materials: " + json_data.data[coidToSearch[x]].Materials + '</li>';
	 res += "<li>ProductionDate: " + json_data.data[coidToSearch[x]].ProductionDate + '</li>';
	 res += "<li>Museum: " + json_data.data[coidToSearch[x]].Museum + '</li>';
	 res += "<li>Description: " + json_data.data[coidToSearch[x]].Description + '</li>';	
	 for (l = 0; l < json_data.data[coidToSearch[x]].Media.length; l++) {
	 res += '<a href="'+json_data.data[coidToSearch[x]].Media[l].Media.large+'" ><img src = "' + json_data.data[coidToSearch[x]].Media[l].Media.small + '"/></a>';	 
	 }	 
	 res += "</p>";
	 res += "<hr>";
	}
	if (coidToSearch.length == 0) { // if no results specify no results found.
		res = "<h1><p> No Results Found </p></h1>";
	}
	$('#box1').html(res); // send back to the HTML
}
function renderRchResults(json_data) { // this function was created by the original owner of the API Ben Jackson
    
    var strHtml = '<ul>';
    strHtml += "<li>COId: " + json_data.data.COId + '</li>';
    strHtml += "<li>AccessionNumber: " + json_data.data.AccessionNumber + '</li>';
    strHtml += "<li>Object: " + json_data.data.Object + '</li>';
    strHtml += "<li>CultureGroup: " + json_data.data.CultureGroup + '</li>';
    strHtml += "<li>Dimensions: " + json_data.data.Dimensions + '</li>';
    strHtml += "<li>ProductionDate: " + json_data.data.ProductionDate + '</li>';
    strHtml += "<li>AssociatedPlaces: " + json_data.data.AssociatedPlaces + '</li>';
    strHtml += "<li>AssociatedPeople: " + json_data.data.AssociatedPeople + '</li>';
    strHtml += "<li>Museum: " + json_data.data.Museum + '</li>';
    strHtml += "<li>FK_ExId: " + json_data.data.FK_ExId + '</li>';
    strHtml += "<li>Materials: " + json_data.data.Materials + '</li>';
    strHtml += "<li>Description: " + json_data.data.Description + '</li>';
    strHtml += "<li>ObjectType: " + json_data.data.ObjectType + '</li>';
    //   console.log('json_data.data.Media.length: '+json_data.data.Media.length );
    for (i = 0; i < json_data.data.Media.length; i++) {
        strHtml += '  <li><a href="'+json_data.data.Media[i].Media.large+'" ><img src = " ' + json_data.data.Media[i].Media.small + ' " /></a>';
        strHtml += '<a href="'+json_data.data.Media[i].Media.small+'" >small </a>';
        strHtml += '<a href="'+json_data.data.Media[i].Media.medium+'" >medium </a>';
        strHtml += '<a href="'+json_data.data.Media[i].Media.large+'" >large </a>';  
        strHtml += '<a href="'+json_data.data.Media[i].Media.media+'" >media </a>';
        strHtml += '</li>';
    }
    strHtml += '</ul>';
    $('#box1').html(strHtml);

}
function renderRandItem(json_data) { // this renders a random item 
	var strHtml = '';
	strHtml += "<h2>From the Collection</h2>"; // no for loop needed to iterate since there is only one item being retrieve from the JSON call.
	strHtml += "<li>COId: " + json_data.data.COId + '</li>';
	strHtml += "<li>Object: " + json_data.data.Object + '</li>';
	strHtml += "<li>CultureGroup: " + json_data.data.CultureGroup + '</li>';
	strHtml += "<li>Museum: " + json_data.data.Museum + '</li>';
	 strHtml += '  <li><a href="'+json_data.data.Media[0].Media.large+'" ><img src = " ' + json_data.data.Media[0].Media.small + ' " /></a></li>';
	 strHtml += '<p><a class="btn btn-default" href="results.html?searchTerm=' + json_data.data.COId +'" role="button">View details &raquo;</a></p>';
	 $('#sec5').html(strHtml); //return to the HTML
}

function renderRchResultsTitle(json_data) {    
    var strHtml = '';    
    strHtml += '<a href="'+json_data.data.Media[1].Media.medium+'" ><img src = " ' + json_data.data.Media[1].Media.medium + ' " /> </a>';    
    $('#results_widget').html(strHtml);
}



function renderRchMediaObject(json_data) { // this function was created by the original owner of the API Ben Jackson
    var strHtml = '<ul>';
    strHtml += "<li>AMOId: " + json_data.data.AMOId + '</li>';
    strHtml += "<li>AssociatedMediaFileName: " + json_data.data.AssociatedMediaFileName + '</li>';
    strHtml += "<li>AssociatedMediaTitle: " + json_data.data.AssociatedMediaTitle + '</li>';
    strHtml += "<li>AssociatedMediaDescription: " + json_data.data.AssociatedMediaDescription + '</li>';
    var AssociatedMediaType = json_data.data.AssociatedMediaType;
    strHtml += "<li>AssociatedMediaType: " + AssociatedMediaType + '</li>';
    strHtml += "<li>FK_ExId: " + json_data.data.FK_ExId + '</li>';
    strHtml += "<li>FK_COId: " + json_data.data.FK_COId + '</li>';
    if (AssociatedMediaType == 'Image') {
        strHtml += '<img src = " ' + json_data.data.media.large + ' " />';
    } else if (AssociatedMediaType == 'Audio') {
        strHtml += '<img src = " ' + json_data.data.media.large + ' " />';
        strHtml += '</li><li><audio controls > <source src =' + json_data.data.media.media + '.mp3 type = "audio/mpeg" > Your browser does not support the audio element. </audio>';
    } else if (AssociatedMediaType == 'Video') {
            strHtml += ' <a href="'+json_data.data.media.media  + '.ogv'+ ' " >';
            strHtml += '<img src = " ' + json_data.data.media .small + ' " />';
            strHtml += '</a>';
            strHtml += ' <a href="'+json_data.data.media.media  + '.mp4'+ ' " >';
            strHtml += 'mp4';
            strHtml += '</a>';
            strHtml += ' - ';
            strHtml += ' <a href="'+json_data.data.media.media  + '.flv'+ ' " >';
            strHtml += 'flv';
            strHtml += '</a>'; 
            strHtml += ' - ';           
            strHtml += ' <a href="'+json_data.data.media.large +'">';
            strHtml += 'Large thumb (with play icon)';
            strHtml += '</a>';  
    }
    strHtml += '</li></ul>';
//    strHtml += '</ul>';
    $('#results_widget').html(strHtml);
}

function renderRchAssociated(json_data) { // this function was created by the original owner of the API Ben Jackson
    var strHtml = '';
    for (i = 0; i < json_data.data.length; i++) {
        strHtml += "<ul><li>AMOId: " + json_data.data[i].AMOId + '</li>';
        strHtml += "<li>AssociatedMediaFileName: " + json_data.data[i].AssociatedMediaFileName + '</lili>';
        strHtml += "<li>AssociatedMediaTitle: " + json_data.data[i].AssociatedMediaTitle + '</li>';
        strHtml += "<li>AssociatedMediaDescription: " + json_data.data[i].AssociatedMediaDescription + '</li>';
        var AssociatedMediaType = json_data.data[i].AssociatedMediaType;
        strHtml += "<li>AssociatedMediaType: " + AssociatedMediaType + '</li>';
        strHtml += "<li>FK_ExId: " + json_data.data[i].FK_ExId + '</li>';
        strHtml += "<li>FK_COId: " + json_data.data[i].FK_COId + '</li>';
        strHtml += "<li>MediaObjects: " + '</li><li>';
        if (AssociatedMediaType == 'Image') {
            strHtml += '<img src = " ' + json_data.data[i].MediaObjects.large + ' " />';
        } else if (AssociatedMediaType == 'Audio') {
            strHtml += '<img src = " ' + json_data.data[i].MediaObjects[j].Media.large + ' " />';
            strHtml += '<audio controls > <source src =' + json_data.data[i].MediaObjects.media + '.mp3 type = "audio/mpeg" > Your browser does not support the audio element. </audio>';
        } else if (AssociatedMediaType == 'Video') {
            strHtml += ' <a href="'+json_data.data[i].MediaObjects.media + '.ogv'+ ' " >';
            strHtml += '<img src = " ' + json_data.data[i].MediaObjects.small + ' " />';
            strHtml += '</a>';
            strHtml += ' <a href="'+json_data.data[i].MediaObjects.media + '.mp4'+ ' " >';
            strHtml += 'mp4';
            strHtml += '</a>';
            strHtml += ' - ';
            strHtml += ' <a href="'+json_data.data[i].MediaObjects.media + '.flv'+ ' " >';
            strHtml += 'flv';
            strHtml += '</a>'; 
            strHtml += ' - ';           
            strHtml += ' <a href="'+json_data.data[i].MediaObjects.large +'">';
            strHtml += 'Large thumb (with play icon)';
            strHtml += '</a>';              
            //strHtml +=
            //    '<video id="example_video_1" class="video-js" width="640" height="480" controls="" preload="auto"><source src=' + json_data.data[i].MediaObjects.media + '.ogv' + ' type="video/ogg; codecs=&quot;theora, vorbis&quot;"><source src=' + json_data.data[i].MediaObjects.media + '.flv' + ' type="video/flv; codecs=&quot;avc1.42E01E, mp4a.40.2&quot;"><source src=' + json_data.data[i].MediaObjects.media + '.mp4' + ' type="video/mp4; codecs=&quot;avc1.42E01E, mp4a.40.2&quot;">' + '<!-- Flash Fallback. Use any flash video player here. Make sure to keep the vjs-flash-fallback class. -->' + '<object id="flash_fallback_1" class="vjs-flash-fallback" width="640" height="480" type="application/x-shockwave-flash" data="http://releases.flowplayer.org/swf/flowplayer-3.2.1.swf">' + ' <param name = "movie"  value = "http://releases.flowplayer.org/swf/flowplayer-3.2.1.swf" >   < param name = "allowfullscreen"  value = "true" > < param name = "flashvars" value = "config={&quot;playlist&quot;:[{&quot;url&quot;: &quot;' + json_data.data[i].MediaObjects.media + '.flv;&quot;,&quot;autoPlay&quot;:false,&quot;autoBuffering&quot;:true}]}">'                
            //    + '</object></video>';
        }
        strHtml += '</li></ul>';
    }
    $('#results_widget').html(strHtml);
}



function renderRchVideosAll(json_data) { // this function was created by the original owner of the API Ben Jackson
    var strHtml = '';
    for (i = 0; i < json_data.data.length; i++) {
        strHtml += "<ul><li>AMOId: " + json_data.data[i].AMOId + '</li>';
        strHtml += "<li>AssociatedMediaFileName: " + json_data.data[i].AssociatedMediaFileName + '</lili>';
        strHtml += "<li>AssociatedMediaTitle: " + json_data.data[i].AssociatedMediaTitle + '</li>';
        strHtml += "<li>AssociatedMediaDescription: " + json_data.data[i].AssociatedMediaDescription + '</li>';
        var AssociatedMediaType = json_data.data[i].AssociatedMediaType;
        strHtml += "<li>AssociatedMediaType: " + AssociatedMediaType + '</li>';
        strHtml += "<li>FK_ExId: " + json_data.data[i].FK_ExId + '</li>';
        strHtml += "<li>FK_COId: " + json_data.data[i].FK_COId + '</li>';
        strHtml += "<li>MediaObjects: " + '</li><li>';
        if (AssociatedMediaType == 'Image') {
            strHtml += '<img src = " ' + json_data.data[i].MediaObjects.large + ' " />';
        } else if (AssociatedMediaType == 'Audio') {
            strHtml += '<img src = " ' + json_data.data[i].MediaObjects[j].Media.large + ' " />';
            strHtml += '<audio controls > <source src =' + json_data.data[i].MediaObjects.media + '.mp3 type = "audio/mpeg" > Your browser does not support the audio element. </audio>';
        } else if (AssociatedMediaType == 'Video') {
            strHtml += ' <a href="'+json_data.data[i].MediaObjects.media + '.ogv'+ ' " >';
            strHtml += '<img src = " ' + json_data.data[i].MediaObjects.small + ' " />';
            strHtml += '</a>';
            strHtml += ' <a href="'+json_data.data[i].MediaObjects.media + '.mp4'+ ' " >';
            strHtml += 'mp4';
            strHtml += '</a>';
            strHtml += ' <a href="'+json_data.data[i].MediaObjects.media + '.flv'+ ' " >';
            strHtml += 'flv';
            strHtml += '</a>';            
            strHtml += ' <a href="'+json_data.data[i].MediaObjects.large +'">';
            strHtml += 'Large thumb (with play icon)';
            strHtml += '</a>';  


        }
        strHtml += '</li></ul><hr />';
    }
    $('#results_widget').html(strHtml);
}
function renderVideosAll(json_data) { //returns all unique videos
    var strHtml = '';
    var names = new Array(); //an array that will be used for storing names of all found videos
	for (i = 0; i < json_data.data.length; i++) { //for all media data 
      	
		var isit = false;   
		for(j = 0; j < names.length; j++){ 
			if (json_data.data[i].AssociatedMediaFileName.toUpperCase() == names[j]){ // if already been found variable is true
				isit = true;
			}
		}
        if (json_data.data[i].AssociatedMediaType == 'Video' && !isit && (json_data.data[i].AssociatedMediaFileName != "female_figure")) { // if a video and not already found.
			
            strHtml += ' <a href="'+json_data.data[i].MediaObjects.media + '.mp4'+ '" data-group="mygroup" data-thumbnail="'+json_data.data[i].MediaObjects.small+'" class = "html5lightbox" title="'+json_data.data[i].AssociatedMediaFileName+' " >';
            strHtml += '<img src = "'+json_data.data[i].MediaObjects.small+'" />';
            strHtml += '</a>';
			
            names.push(json_data.data[i].AssociatedMediaFileName.toUpperCase()); // put name in array.
		 }
	 }
	strHtml += '<script type="text/javascript"> $(".html5lightbox").html5lightbox();</script>'; //reload the plug-in to make work.
    $('#video_panel').html(strHtml);// send back to HTML
}

function renderRchCollectionByMuseum(json_data) { // this function was created by the original owner of the API Ben Jackson
    var strHtml = '';
    for (i = 0; i < json_data.data.Objects.length; i++) {
        strHtml += "<ul><li>COId: " + json_data.data.Objects[i].COId + '</li>';
        strHtml += "<li>AccessionNumber: " + json_data.data.Objects[i].AccessionNumber + '</li>';
        strHtml += "<li>ObjectType: " + json_data.data.Objects[i].ObjectType + '</li>';
        strHtml += "<li>Object: " + json_data.data.Objects[i].Object + '</li>';
        strHtml += "<li>Description: " + json_data.data.Objects[i].Description + '</li>';
        strHtml += "<li>Materials: " + json_data.data.Objects[i].Materials + '</li>';
        strHtml += "<li>CultureGroup: " + json_data.data.Objects[i].CultureGroup + '</li>';
        strHtml += "<li>Dimensions: " + json_data.data.Objects[i].Dimensions + '</li>';
        strHtml += "<li>ProductionDate: " + json_data.data.Objects[i].ProductionDate + '</li>';
        strHtml += "<li>AssociatedPlaces: " + json_data.data.Objects[i].AssociatedPlaces + '</li>';
        strHtml += "<li>AssociatedPeople: " + json_data.data.Objects[i].AssociatedPeople + '</li>';
        strHtml += "<li>Museum: " + json_data.data.Objects[i].Museum + '</li>';
        strHtml += "<li>FK_ExId: " + json_data.data.Objects[i].FK_ExId + '</li>';
        strHtml += "<li>MediaObjects []: " + '</li></ul>';
        strHtml += '<ul>';
        for (j = 0; j < json_data.data.Objects[i].MediaObjects.length; j++) {
            //strHtml += JSON.stringify(json_data.data[i].MediaObjects[j]);
            //json_media_array = json_data.data.Media[i];
            strHtml += '<ul>';
            strHtml += '';
            strHtml += '<li>MediaTitle: ';
            strHtml += json_data.data.Objects[i].MediaObjects[j].MediaTitle;
            strHtml += '</li>';
            strHtml += '<li>MediaDescription: ';
            strHtml += json_data.data.Objects[i].MediaObjects[j].MediaDescription;
            strHtml += '</li>';
            strHtml += '<li>MediaFileName: ';
            strHtml += json_data.data.Objects[i].MediaObjects[j].MediaFileName;
            strHtml += '</li>';
            strHtml += '<li>MediaType: ';
            var mediaType = json_data.data.Objects[i].MediaObjects[j].MediaType;
            strHtml += mediaType;
            strHtml += '</li>';
            strHtml += '<li>MediaObjects: ';
            strHtml += json_data.data.Objects[i].MediaObjects[j].FK_COId;
            strHtml += '</li><li>';
            //Inspect JSON result for additional media options (e.g. alternative image sizes)
            if (mediaType == 'Image') {
                strHtml += '<img src = " ' + json_data.data.Objects[i].MediaObjects[j].Media.large + ' " />';
            } else if (mediaType == 'Audio') {
                strHtml += '<img src = " ' + json_data.data.Objects[i].MediaObjects[j].Media.large + ' " />';
                strHtml += '</li><li><audio controls > <source src =' + json_data.data.Objects[i].MediaObjects[j].Media.media + '.mp3 type = "audio/mpeg" > Your browser does not support the audio element. </audio>';
            } else if (mediaType == 'Video') {
                strHtml +=
                    '<video id="example_video_1" class="video-js" width="640" height="480" controls="" preload="auto"><source src=' + json_data.data[i].MediaObjects[j].Media.media + '.ogv' + ' type="video/ogg; codecs=&quot;theora, vorbis&quot;"><source src=' + json_data.data[i].MediaObjects[j].Media.media + '.flv' + ' type="video/flv; codecs=&quot;avc1.42E01E, mp4a.40.2&quot;"><source src=' + json_data.data[i].MediaObjects[j].Media.media + '.mp4' + ' type="video/mp4; codecs=&quot;avc1.42E01E, mp4a.40.2&quot;">' + '<!-- Flash Fallback. Use any flash video player here. Make sure to keep the vjs-flash-fallback class. -->' + '<object id="flash_fallback_1" class="vjs-flash-fallback" width="640" height="480" type="application/x-shockwave-flash" data="http://releases.flowplayer.org/swf/flowplayer-3.2.1.swf">' + ' < param name = "movie"  value = "http://releases.flowplayer.org/swf/flowplayer-3.2.1.swf" >   < param name = "allowfullscreen"  value = "true" > < param name = "flashvars" value = "config={&quot;playlist&quot;:[{&quot;url&quot;: &quot;' + json_data.data[i].MediaObjects[j].Media.media + '.flv;&quot;,&quot;autoPlay&quot;:false,&quot;autoBuffering&quot;:true}]}">'
                    /* - to do ben            
                    +<!-- Image Fallback. Typically the same as the poster image. -->'
                    +'<img src='
                    +"http://www.sierraleoneheritage.org/assets/objects/associated_media/video/thumbs/large/sowei.jpg" +' width="640" height="264" alt="Poster Image" title="No video playback capabilities." class="lightbox">*/
                    + '</object></video>';
            }
            strHtml += '</li></ul>';
        }
        strHtml += '</ul>';


    }
    strHtml += '</ul>';
    $('#results_widget').html(strHtml);
}
function renderMuseumSliders(json_data) {
	var iscoot = false; //variable used to see if of cootje van over collection
	var cooty = 'Cootje van Oven Collection'; //comparison variable
	var arrayOfMusuem = ['Sierra Leone National Museum', 'British Museum', 'Cootje van Oven Collection', 'Brighton Museum and Art Gallery', 'Glasgow Museums', 'World Museum Liverpool'];
	var strHtml= '';//return string
	for (y = 0; y < arrayOfMusuem.length; y++){ // for all museums in list arrayOfMuseum
	var limit = 0;//line below sets up jssor plug in for each different slider
	strHtml += '<p><p><h66>'+arrayOfMusuem[y]+'</h66></p><div id="jssor_'+y+'" style="position: relative; margin: 0 auto; top: 0px; left: 0px; width: 980px; height: 100px; overflow: hidden; visibility: hidden;">     <div data-u="loading" style="position: absolute; top: 0px; left: 0px;"><div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div><div style="position:absolute;display:block;background:url(\'img/loading.gif\') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div></div><div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; width: 980px; height: 100px; overflow: hidden;">';
	for (i = 0; i < json_data.data.length; i++){
		if(arrayOfMusuem[y]==cooty && (limit < 50)){ //hard code limit to stop lag
			iscoot = true;
		}
		if(json_data.data[i].Museum==arrayOfMusuem[y]&& !iscoot && (limit < 50)){  //matches if museum in array matches museum of database and is not from cootje van collection
			strHtml += '<div style="display: none;">';
			strHtml += '<a href="results.html?searchTerm=' + json_data.data[i].COId +'"style="display: block; top: 0px; left: 0px; width: 140px; height: 100px; position: relative;" >';
			strHtml += '<img data-u="image" src= "' + json_data.data[i].Media[0].Media.small + '" border="0" style="top: 0px; left: 0px; width: 140px; height: 100px; position: absolute;"></a>';
			strHtml += '</div>'
			iscoot = false;
			limit++;//+counter			
	}
	if(json_data.data[i].Museum==arrayOfMusuem[y]&& iscoot && (limit < 50)){ // matches if museum in array and in cootje van collection
			strHtml += '<div style="display: none;">'; // the reason why it has to be cootje manually is because the way it's been entered in the database. Images are second in the array and not first.
			strHtml += '<a href="results.html?searchTerm=' + json_data.data[i].COId +'"style="display: block; top: 0px; left: 0px; width: 140px; height: 100px; position: relative;" >';
			strHtml += '<img data-u="image" src= "' + json_data.data[i].Media[1].Media.small + '" border="0" style="top: 0px; left: 0px; width: 140px; height: 100px; position: absolute;"></a>';
			strHtml += '</div>'
			iscoot = false;
			limit++;//+ counter
			}
	}
strHtml+= '<a data-u="ad" href="http://www.jssor.com" style="display:none">Responsive Slider</a></div></div>';	
strHtml += '</p><p></p>';
strHtml += '<script>jQuery(document).ready(function ($) { var jssor_'+y+'_options = { $AutoPlay: true, $Idle: 0, $AutoPlaySteps: 4, $SlideDuration: 1600, $SlideEasing: $Jease$.$Linear, $PauseOnHover: 4,   $SlideWidth: 140, $Cols: 7}; var jssor_'+y+'_slider = new $JssorSlider$("jssor_'+y+'", jssor_'+y+'_options); }); </script>';
	
	}
	$('#sliderBox').html(strHtml); //send back to the HTML

}
function renderRchCollection(json_data) { // this function was created by the original owner of the API Ben Jackson
    //  strHtml = JSON.stringify(json_data.data[1].MediaObjects);
    var strHtml = '';
    for (i = 0; i < json_data.data.length; i++) {
        strHtml += "<ul><li>COId: " + json_data.data[i].COId + '</li>';
        strHtml += "<li>AccessionNumber: " + json_data.data[i].AccessionNumber + '</li>';
        strHtml += "<li>ObjectType: " + json_data.data[i].ObjectType + '</li>';
        strHtml += "<li>Object: " + json_data.data[i].Object + '</li>';
        strHtml += "<li>Description: " + json_data.data[i].Description + '</li>';
        strHtml += "<li>Materials: " + json_data.data[i].Materials + '</li>';
        strHtml += "<li>CultureGroup: " + json_data.data[i].CultureGroup + '</li>';
        strHtml += "<li>Dimensions: " + json_data.data[i].Dimensions + '</li>';
        strHtml += "<li>ProductionDate: " + json_data.data[i].ProductionDate + '</li>';
        strHtml += "<li>AssociatedPlaces: " + json_data.data[i].AssociatedPlaces + '</li>';
        strHtml += "<li>AssociatedPeople: " + json_data.data[i].AssociatedPeople + '</li>';
        strHtml += "<li>Museum: " + json_data.data[i].Museum + '</li>';
        strHtml += "<li>FK_ExId: " + json_data.data[i].FK_ExId + '</li>';

        strHtml += '  <li>';
        for(var j=0;j<json_data.data[i].Media.length;j++){
            strHtml += '<a href="'+json_data.data[i].Media[j].Media.large+'" ><img src = "' + json_data.data[i].Media[j].Media.small + '"/></a>';
            strHtml += '<a href="'+json_data.data[i].Media[j].Media.small+'" >small </a>';
            strHtml += '<a href="'+json_data.data[i].Media[j].Media.medium+'" >medium </a>';
            strHtml += '<a href="'+json_data.data[i].Media[j].Media.large+'" >large </a>';  
            strHtml += '<a href="'+json_data.data[i].Media[j].Media.media+'" >media </a>';
        }
        strHtml += '  </li>';
        strHtml += /*"<li>MediaObjects []: " + */'</ul>';
        strHtml += '<hr />';
        //   for (k = 0; k < json_data[i][j].Media.length; k++) {
       // strHtml += '<li><img src = " ' + json_data.data[i].Media[0].Media.small + ' " /></li>';

        //   }n        
    }
    $('#box1').html(strHtml);
}



function renderRchRelated(json_data) {  // this function was created by the original owner of the API Ben Jackson
    //  strHtml = JSON.stringify(json_data.data[1].MediaObjects);
    var strHtml = '';
    for (i = 0; i < json_data.data.length; i++) {
        strHtml += "<ul><li>COId: " + json_data.data[i].COId + '</li>';
        strHtml += "<li>AccessionNumber: " + json_data.data[i].AccessionNumber + '</li>';
        strHtml += "<li>ObjectType: " + json_data.data[i].ObjectType + '</li>';
        strHtml += "<li>Object: " + json_data.data[i].Object + '</li>';
        strHtml += "<li>Description: " + json_data.data[i].Description + '</li>';
        strHtml += "<li>Materials: " + json_data.data[i].Materials + '</li>';
        strHtml += "<li>CultureGroup: " + json_data.data[i].CultureGroup + '</li>';
        strHtml += "<li>Dimensions: " + json_data.data[i].Dimensions + '</li>';
        strHtml += "<li>ProductionDate: " + json_data.data[i].ProductionDate + '</li>';
        strHtml += "<li>AssociatedPlaces: " + json_data.data[i].AssociatedPlaces + '</li>';
        strHtml += "<li>AssociatedPeople: " + json_data.data[i].AssociatedPeople + '</li>';
        strHtml += "<li>Museum: " + json_data.data[i].Museum + '</li>';
        strHtml += "<li>FK_ExId: " + json_data.data[i].FK_ExId + '</li>';
        strHtml += "<li>MediaObjects []: " + '</li></ul>';
        strHtml += '<ul>';
        for (j = 0; j < json_data.data[i].MediaObjects.length; j++) {
            //strHtml += JSON.stringify(json_data.data[i].MediaObjects[j]);
            //json_media_array = json_data.data.Media[i];
            strHtml += '<ul>';
            strHtml += '';
            strHtml += '<li>MediaTitle: ';
            strHtml += json_data.data[i].MediaObjects[j].MediaTitle;
            strHtml += '</li>';
            strHtml += '<li>MediaDescription: ';
            strHtml += json_data.data[i].MediaObjects[j].MediaDescription;
            strHtml += '</li>';
            strHtml += '<li>MediaFileName: ';
            strHtml += json_data.data[i].MediaObjects[j].MediaFileName;
            strHtml += '</li>';
            strHtml += '<li>MediaType: ';
            var mediaType = json_data.data[i].MediaObjects[j].MediaType;
            strHtml += mediaType;
            strHtml += '</li>';
            strHtml += '<li>MediaObjects: ';
            strHtml += json_data.data[i].MediaObjects[j].FK_COId;
            strHtml += '</li><li>';
            //Inspect JSON result for additional media options (e.g. alternative image sizes)
            if (mediaType == 'Image') {
                strHtml += '<img src = " ' + json_data.data[i].MediaObjects[j].Media.large + ' " />';
            } else if (mediaType == 'Audio') {
                strHtml += '<img src = " ' + json_data.data[i].MediaObjects[j].Media.large + ' " />';
                strHtml += '</li><li><audio controls > <source src =' + json_data.data[i].MediaObjects[j].Media.media + '.mp3 type = "audio/mpeg" > Your browser does not support the audio element. </audio>';
            } else if (mediaType == 'Video') {
                strHtml +=
                    '<video id="example_video_1" class="video-js" width="640" height="480" controls="" preload="auto"><source src=' + json_data.data[i].MediaObjects[j].Media.media + '.ogv' + ' type="video/ogg; codecs=&quot;theora, vorbis&quot;"><source src=' + json_data.data[i].MediaObjects[j].Media.media + '.flv' + ' type="video/flv; codecs=&quot;avc1.42E01E, mp4a.40.2&quot;"><source src=' + json_data.data[i].MediaObjects[j].Media.media + '.mp4' + ' type="video/mp4; codecs=&quot;avc1.42E01E, mp4a.40.2&quot;">' + '<!-- Flash Fallback. Use any flash video player here. Make sure to keep the vjs-flash-fallback class. -->' + '<object id="flash_fallback_1" class="vjs-flash-fallback" width="640" height="480" type="application/x-shockwave-flash" data="http://releases.flowplayer.org/swf/flowplayer-3.2.1.swf">' + ' < param name = "movie"  value = "http://releases.flowplayer.org/swf/flowplayer-3.2.1.swf" >   < param name = "allowfullscreen"  value = "true" > < param name = "flashvars" value = "config={&quot;playlist&quot;:[{&quot;url&quot;: &quot;' + json_data.data[i].MediaObjects[j].Media.media + '.flv;&quot;,&quot;autoPlay&quot;:false,&quot;autoBuffering&quot;:true}]}">'
                    /* - to do ben            
                    +<!-- Image Fallback. Typically the same as the poster image. -->'
                    +'<img src='
                    +"http://www.sierraleoneheritage.org/assets/objects/associated_media/video/thumbs/large/sowei.jpg" +' width="640" height="264" alt="Poster Image" title="No video playback capabilities." class="lightbox">*/
                    + '</object></video>';
            }
            strHtml += '</li></ul>';
        }
        strHtml += '</ul>';
        strHtml += '<br />';
    }
    $('#results_widget').html(strHtml);
}




function renderRchRelatedItems(json_data) { // this function was created by the original owner of the API Ben Jackson
    var strHtml = '<ul>'
    for (i = 0; i < json_data.data.length; i++) {
        //for (j = 0; j < json_data[i].length; j++) {
        //strHtml += '<li>' + JSON.stringify(json_data[i][j]) + '</li>';            
        strHtml += "<li>COId: " + json_data.data[i].COId + '</li>';
        strHtml += "<li>AccessionNumber: " + json_data.data[i].AccessionNumber + '</li>';
        strHtml += "<li>Object: " + json_data.data[i].Object + '</li>';
        strHtml += "<li>CultureGroup: " + json_data.data[i].CultureGroup + '</li>';
        strHtml += "<li>Dimensions: " + json_data.data[i].Dimensions + '</li>';
        strHtml += "<li>ProductionDate: " + json_data.data[i].ProductionDate + '</li>';
        strHtml += "<li>AssociatedPlaces: " + json_data.data[i].AssociatedPlaces + '</li>';
        strHtml += "<li>AssociatedPeople: " + json_data.data[i].AssociatedPeople + '</li>';
        strHtml += "<li>Museum: " + json_data.data[i].Museum + '</li>';
        strHtml += "<li>FK_ExId: " + json_data.data[i].FK_ExId + '</li>';
        strHtml += "<li>Materials: " + json_data.data[i].Materials + '</li>';
        strHtml += "<li>Description: " + json_data.data[i].Description + '</li>';
        strHtml += "<li>ObjectType: " + json_data.data[i].ObjectType + '</li>';
        //   strHtml += "<li><p>The images/media are avaialable in more sizes -- see JSON response for other options   </p></li>";
        //   for (k = 0; k < json_data[i][j].Media.length; k++) {
        strHtml += '<li><img src = " ' + json_data.data[i].Media[0].Media.small + ' " /></li>';
        //   }
        //}
    }
    strHtml += '</ul>';
    $('#results_widget').html(strHtml);
}



function renderRchRelatedList(json_data) {  // this function was created by the original owner of the API Ben Jackson
    var strHtml = '<ul>'
    for (i = 0; i < json_data.data.length; i++) {
        //for (j = 0; j < json_data[i].length; j++) {
        //strHtml += '<li>' + JSON.stringify(json_data[i][j]) + '</li>';            
        strHtml += "<li>COId: " + json_data.data[i].COId + '</li>';
        /*strHtml += "<li>AccessionNumber: " + json_data[i][j].AccessionNumber + '</li>';
        strHtml += "<li>Object: " + json_data[i][j].Object + '</li>';
        strHtml += "<li>CultureGroup: " + json_data[i][j].CultureGroup + '</li>';
        strHtml += "<li>Dimensions: " + json_data[i][j].Dimensions + '</li>';
        strHtml += "<li>ProductionDate: " + json_data[i][j].ProductionDate + '</li>';
        strHtml += "<li>AssociatedPlaces: " + json_data[i][j].AssociatedPlaces + '</li>';
        strHtml += "<li>AssociatedPeople: " + json_data[i][j].AssociatedPeople + '</li>';
        strHtml += "<li>Museum: " + json_data[i][j].Museum + '</li>';
        strHtml += "<li>FK_ExId: " + json_data[i][j].FK_ExId + '</li>';
        strHtml += "<li>Materials: " + json_data[i][j].Materials + '</li>';
        strHtml += "<li>Description: " + json_data[i][j].Description + '</li>';
        strHtml += "<li>ObjectType: " + json_data[i][j].ObjectType + '</li>';*/
        //   strHtml += "<li><p>The images/media are avaialable in more sizes -- see JSON response for other options   </p></li>";
        //   for (k = 0; k < json_data[i][j].Media.length; k++) {
        strHtml += '<li><img src = " ' + json_data.data[i].Media[0].Media.small + ' " /></li>';
        //   }
        //}
    }
    strHtml += '</ul>';
    $('#results_widget').html(strHtml);
}



function renderRchRelatedItems2(json_data) {  // this function was created by the original owner of the API Ben Jackson
    //  strHtml = JSON.stringify(json_data.data[1].MediaObjects);
    var strHtml = '';
    for (i = 0; i < json_data.data.length; i++) {
        strHtml += "<ul><li>COId: " + json_data.data[i].COId + '</li>';
        strHtml += "<li>AccessionNumber: " + json_data.data[i].AccessionNumber + '</li>';
        strHtml += "<li>ObjectType: " + json_data.data[i].ObjectType + '</li>';
        strHtml += "<li>Object: " + json_data.data[i].Object + '</li>';
        strHtml += "<li>Description: " + json_data.data[i].Description + '</li>';
        strHtml += "<li>Materials: " + json_data.data[i].Materials + '</li>';
        strHtml += "<li>CultureGroup: " + json_data.data[i].CultureGroup + '</li>';
        strHtml += "<li>Dimensions: " + json_data.data[i].Dimensions + '</li>';
        strHtml += "<li>ProductionDate: " + json_data.data[i].ProductionDate + '</li>';
        strHtml += "<li>AssociatedPlaces: " + json_data.data[i].AssociatedPlaces + '</li>';
        strHtml += "<li>AssociatedPeople: " + json_data.data[i].AssociatedPeople + '</li>';
        strHtml += "<li>Museum: " + json_data.data[i].Museum + '</li>';
        strHtml += "<li>FK_ExId: " + json_data.data[i].FK_ExId + '</li>';
        strHtml += "<li>MediaObjects []: " + '</li></ul>';
        strHtml += '<ul>';
        for (j = 0; j < json_data.data[i].MediaObjects.length; j++) {
            //strHtml += JSON.stringify(json_data.data[i].MediaObjects[j]);
            //json_media_array = json_data.data.Media[i];
            strHtml += '<ul>';
            strHtml += '';
            strHtml += '<li>MediaTitle: ';
            strHtml += json_data.data[i].MediaObjects[j].MediaTitle;
            strHtml += '</li>';
            strHtml += '<li>MediaDescription: ';
            strHtml += json_data.data[i].MediaObjects[j].MediaDescription;
            strHtml += '</li>';
            strHtml += '<li>MediaFileName: ';
            strHtml += json_data.data[i].MediaObjects[j].MediaFileName;
            strHtml += '</li>';
            strHtml += '<li>MediaType: ';
            var mediaType = json_data.data[i].MediaObjects[j].MediaType;
            strHtml += mediaType;
            strHtml += '</li>';
            strHtml += '<li>MediaObjects: ';
            strHtml += json_data.data[i].MediaObjects[j].FK_COId;
            strHtml += '</li><li>';
            //Inspect JSON result for additional media options (e.g. alternative image sizes)
            if (mediaType == 'Image') {
                strHtml += '<img src = " ' + json_data.data[i].MediaObjects[j].Media.large + ' " />';
            } else if (mediaType == 'Audio') {
                strHtml += '<img src = " ' + json_data.data[i].MediaObjects[j].Media.large + ' " />';
                strHtml += '</li><li><audio controls > <source src =' + json_data.data[i].MediaObjects[j].Media.media + '.mp3 type = "audio/mpeg" > Your browser does not support the audio element. </audio>';
            } else if (mediaType == 'Video') {
                strHtml +=
                    '<video id="example_video_1" class="video-js" width="640" height="480" controls="" preload="auto"><source src=' + json_data.data[i].MediaObjects[j].Media.media + '.ogv' + ' type="video/ogg; codecs=&quot;theora, vorbis&quot;"><source src=' + json_data.data[i].MediaObjects[j].Media.media + '.flv' + ' type="video/flv; codecs=&quot;avc1.42E01E, mp4a.40.2&quot;"><source src=' + json_data.data[i].MediaObjects[j].Media.media + '.mp4' + ' type="video/mp4; codecs=&quot;avc1.42E01E, mp4a.40.2&quot;">' + '<!-- Flash Fallback. Use any flash video player here. Make sure to keep the vjs-flash-fallback class. -->' + '<object id="flash_fallback_1" class="vjs-flash-fallback" width="640" height="480" type="application/x-shockwave-flash" data="http://releases.flowplayer.org/swf/flowplayer-3.2.1.swf">' + ' < param name = "movie"  value = "http://releases.flowplayer.org/swf/flowplayer-3.2.1.swf" >   < param name = "allowfullscreen"  value = "true" > < param name = "flashvars" value = "config={&quot;playlist&quot;:[{&quot;url&quot;: &quot;' + json_data.data[i].MediaObjects[j].Media.media + '.flv;&quot;,&quot;autoPlay&quot;:false,&quot;autoBuffering&quot;:true}]}">'
                    /* - to do ben            
                    +<!-- Image Fallback. Typically the same as the poster image. -->'
                    +'<img src='
                    +"http://www.sierraleoneheritage.org/assets/objects/associated_media/video/thumbs/large/sowei.jpg" +' width="640" height="264" alt="Poster Image" title="No video playback capabilities." class="lightbox">*/
                    + '</object></video>';
            }
            strHtml += '</li></ul>';
        }
        strHtml += '</ul>';
        strHtml += '<br />';
    }
    $('#results_widget').html(strHtml);
}


function renderRchMuseumList(json_data) {  // this function was created by the original owner of the API Ben Jackson
    var strHtml = '<ul>';
    for (i = 0; i < json_data.data.length; i++) {
        strHtml += "<li>Museum: " + json_data.data[i].InstitutionName + '</li>';
    }
    strHtml += '</ul>';
    $('#results_widget').html(strHtml);
}
